import React, { useEffect, useState } from 'react';

const HomePage = () => {

  const handleClick = () => {
    return alert('Hello there');
  }
  
  
  useEffect(() => {
    console.log('HomePage is active');
    document.body.style.backgroundColor = 'lightblue';

    return () => {
      console.log('HomePage is unmounted');
      document.body.style.backgroundColor = ''; // Cleanup
    };
  }, []);

  

  return <div id="HomeContainer">
    <h1>Home Page</h1>
    <button onClick={handleClick}>Click me!</button>
    
  </div> 

};

export default HomePage;